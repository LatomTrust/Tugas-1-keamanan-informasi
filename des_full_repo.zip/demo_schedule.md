# Jadwal Demo - Implementasi DES
Deadline tugas: Senin, 13 Oktober 2025 23:59

Opsi pengumpulan (pilih salah satu):
1) Pengumpulan: **Selasa, 14 Oktober 2025**
   - Slot demo (10 menit): 09:00, 09:10, 09:20, 14:00, 14:10
2) Pengumpulan: **Sabtu, 18 Oktober 2025**
   - Slot demo (10 menit): 10:00, 10:10, 10:20, 15:00, 15:10

File ini ada juga di root: `demo_schedule.md`.
