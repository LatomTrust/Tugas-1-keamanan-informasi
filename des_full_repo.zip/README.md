# Tugas Keamanan Informasi — Implementasi DES (Python & C++)
Repositori ini berisi dua implementasi pendidikan DES (Data Encryption Standard):
- `python/` — implementasi DES murni di Python (ECB, PKCS#7 padding) dengan CLI
- `cpp/` — implementasi DES di C++ (ECB, PKCS#7 padding) dengan Makefile

File-file di dalam repo sudah dikemas supaya kamu tinggal copy-paste ke GitHub atau unzip dan langsung pakai.

**Catatan penting**: Implementasi ini dibuat untuk tugas/pendidikan — **tidak** untuk produksi.

---
## Struktur
- python/
  - des.py
  - cli.py
  - test_vectors.txt
  - README.md
- cpp/
  - des.cpp
  - cli.cpp
  - Makefile
  - README.md
- demo_schedule.md
- README.md (this file)

## Cara singkat pakai (Python)
```bash
# Enkripsi
python3 python/cli.py encrypt --key 133457799BBCDFF1 --in plain.bin --out cipher.bin

# Dekripsi
python3 python/cli.py decrypt --key 133457799BBCDFF1 --in cipher.bin --out plain_dec.bin
```

## Cara singkat pakai (C++)
Build & pakai:
```bash
cd cpp
make
./des_cli encrypt 133457799BBCDFF1 plain.bin cipher.bin
./des_cli decrypt 133457799BBCDFF1 cipher.bin plain_dec.bin
```

## Deadline / Jadwal demo
Lihat `demo_schedule.md` untuk dua opsi jadwal demo (pilih salah satu).

---
Jika mau aku bisa:
- Tambah mode operasi lain (CBC) dengan IV.
- Buat GitHub repo untukmu dan push (kamu perlu memberikan akses/token).
- Tambah unit tests atau CI (github actions).
